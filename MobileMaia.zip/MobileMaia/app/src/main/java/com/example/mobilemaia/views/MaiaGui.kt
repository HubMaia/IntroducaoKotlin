package com.example.mobilemaia.views


import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.mobilemaia.ui.theme.MobileMaiaTheme
import com.example.mobilemaia.views.widget.TaskMaia

@Composable
fun MaiaGui (){
    MobileMaiaTheme {
        Scaffold( modifier = Modifier.fillMaxSize() ) { innerPadding ->
            TaskMaia()
        }
    }
}