package com.example.mobilemaia.views.widget

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mobilemaia.models.tarefa1
import com.example.mobilemaia.models.tarefa2
import com.example.mobilemaia.models.tarefa3

@Composable
fun TaskMaia () {
    Column {
        Box {
            Column (modifier = Modifier.padding(16.dp)) {
                Text(text = "${tarefa1.titulo}")
                Text(text = "${tarefa1.data}")

                Row {
                    Button(onClick = {  }) {
                        Text("Editar")
                    }
                    Button(onClick = {  }) {
                        Text("Enviar")
                    }
                }

                Text(text = "${tarefa2.titulo}")
                Text(text = "${tarefa2.data}")

                Row {
                    Button(onClick = {  }) {
                        Text("Editar")
                    }
                    Button(onClick = {  }) {
                        Text("Enviar")
                    }
                }

                Text(text = "${tarefa3.titulo}")
                Text(text = "${tarefa3.data}")

                Row {
                    Button(onClick = {  }) {
                        Text("Editar")
                    }
                    Button(onClick = {  }) {
                        Text("Enviar")
                    }
                }

            }
        }
    }
}