package com.example.mobilemaia.models

import java.time.LocalDate

class TarefaClass(
    val titulo: String,
    val data: LocalDate
)

//essas variaveis aparecerao atraves do Text
val tarefa1 = TarefaClass(
    titulo = "Mobile Button",
    data = LocalDate.of(2024, 9, 11)

)
val tarefa2 = TarefaClass(
    titulo = "PHP Login",
    data = LocalDate.of(2024, 10, 10)
)
val tarefa3 = TarefaClass(
    titulo = "Java Herança",
    data = LocalDate.of(2024, 10, 24)
)